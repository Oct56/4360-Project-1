import 'package:flutter/material.dart';

final ThemeData myTheme = ThemeData(

  //colors
  colorScheme: ColorScheme(
    brightness: Brightness.light, 
    primary: Color.fromARGB(255, 233, 234, 235), //check this and surface
    onPrimary: Colors.black54, 
    secondary: const Color.fromARGB(255, 30, 78, 231), 
    onSecondary: Colors.black54, 
    error: Colors.redAccent, 
    onError: Colors.black54, 
    surface: Colors.white, 
    onSurface: Colors.black54,
    outline: Colors.black54,
    shadow: Color.fromARGB(255, 224, 227, 239) ),
  
  //
  fontFamily: 'Roboto',
  
  //specific text sizes according to google material design guidelines
  textTheme: TextTheme(
    displayLarge: TextStyle(fontSize: 96.0, fontWeight: FontWeight.w300, letterSpacing: -1.5),
    displayMedium: TextStyle(fontSize: 60.0, fontWeight: FontWeight.w300, letterSpacing: -0.5),
    displaySmall: TextStyle(fontSize: 48.0, fontWeight: FontWeight.w400, letterSpacing: 0.0),
    
    // Headline
    headlineLarge: TextStyle(fontSize: 34.0, fontWeight: FontWeight.w400, letterSpacing: 0.25),
    headlineMedium: TextStyle(fontSize: 24.0, fontWeight: FontWeight.w500, letterSpacing: 0.0),
    headlineSmall: TextStyle(fontSize: 20.0, fontWeight: FontWeight.w500, letterSpacing: 0.15),
    
    // Title
    titleLarge: TextStyle(fontSize: 16.0, fontWeight: FontWeight.w400, letterSpacing: 0.15),
    titleMedium: TextStyle(fontSize: 14.0, fontWeight: FontWeight.w500, letterSpacing: 0.1),
    titleSmall: TextStyle(fontSize: 12.0, fontWeight: FontWeight.w500, letterSpacing: 0.4),
    
    // Body
    bodyLarge: TextStyle(fontSize: 16.0, fontWeight: FontWeight.w400, letterSpacing: 0.5),
    bodyMedium: TextStyle(fontSize: 14.0, fontWeight: FontWeight.w400, letterSpacing: 0.25),
    bodySmall: TextStyle(fontSize: 12.0, fontWeight: FontWeight.w400, letterSpacing: 0.4),
    
    // Label
    labelLarge: TextStyle(fontSize: 14.0, fontWeight: FontWeight.w400, letterSpacing: 0.15),
    labelMedium: TextStyle(fontSize: 12.0, fontWeight: FontWeight.w500, letterSpacing: 0.4),
    labelSmall: TextStyle(fontSize: 10.0, fontWeight: FontWeight.w500, letterSpacing: 0.5),

  ),
  
  // Define the button themes.
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ButtonStyle(
       backgroundColor: WidgetStateProperty.all<Color>(
              Color.fromARGB(255, 30, 78, 231), // Background color when enabled
            ),
    ),
  ),
  
  // Define the card theme.
  cardTheme: CardTheme(
    elevation: 4.0,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(8.0),
    ),
  ),
  
  // Define the input decoration theme for text fields.
  inputDecorationTheme: InputDecorationTheme(
    border: OutlineInputBorder(),
    focusedBorder: OutlineInputBorder(
      borderSide: BorderSide(color:const Color.fromARGB(255, 30, 78, 231), width: 2.0),
    ),
    labelStyle: TextStyle(color: const Color.fromARGB(255, 30, 78, 231)),
  ),
);